window.addEventListener('load',()=>{
    const form=document.querySelector('#newform');
    const input=document.querySelector('#newtext');
    const  tasklist=document.querySelector('#task');
    form.addEventListener('submit',(e)=>{
        e.preventDefault();
       const t=input.value;
       const taskel=document.createElement("div");
       taskel.classList.add("t");
       const taskcontent=document.createElement("div");
       taskcontent.classList.add("content");
       taskel.appendChild(taskcontent);
       const taskinput=document.createElement("input");
       taskinput.classList.add("text");
       taskinput.type="text";
       taskinput.value=t;
       taskinput.setAttribute("readonly","readonly");
       taskcontent.appendChild(taskinput);
       const taskaction=document.createElement("div");
       taskaction.classList.add("buttons");
       const taskedit=document.createElement("button")
       taskedit.classList.add("edit");
       taskedit.innerHTML="Edit";
       const taskdelete=document.createElement("button")
       taskdelete.classList.add("delete");
       taskdelete.innerHTML="Delete";
       taskaction.appendChild(taskedit);
       taskaction.appendChild(taskdelete);
       taskel.appendChild(taskaction);
       tasklist.appendChild(taskel);
       input.value="";
       taskedit.addEventListener('click', () =>{
           if(taskedit.innerText.toLowerCase()=="edit"){
               taskinput.removeAttribute("readonly");
               taskinput.focus();
               taskedit.innerText="Save";
           }
           else{
               taskinput.setAttribute("readonly","readonly");
               taskedit.innerText="Edit";
           }
       });
       taskdelete.addEventListener('click',() =>{
                tasklist.removeChild(taskel);
       });
 })
})